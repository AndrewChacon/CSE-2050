from Node import _Node

class Stack_L:
    def __init__(self):
        self._L = list()    # Composition: the Stack_L class has a List

    def push(self, item):
        pass

    def pop(self):
        """ Remove and returns the element at the top of stack"""
        #Raises error when trying to pop from the empty stack
        pass

    def peek(self):
        #Raises error when trying to pop from the empty stack
        pass

    def __len__(self):
        pass

    def isempty(self):
        pass

class Queue_L:
    def __init__(self):
        self._L = []

    def enqueue(self, item):
        pass

    def dequeue(self):
        #Raises error when trying to deque from the empty queue
        pass

    def peek(self):
        pass

    def __len__(self):
        pass

    def isempty(self):
        pass

class Stack_LL:
    def __init__(self):
        self._head = None
        self._size = 0

    def __len__(self):
        """ Returns the size of the stack """
        pass

    def is_empty(self):
        """ Returns True if the stack is empty"""
        pass

    def push(self, element):
        """ Add "element" to the top of the stack """
        pass

    def pop(self):
        """ Remove element from the top of the stack """
        pass

    def top(self):
        """ Only read the element and donot remove it. """
        pass

class Queue_LL:
    def __init__(self):
        self._head = None
        self._tail = None
        self._size = 0

    def __len__(self):
        """ Returns the size of the queue """
        pass

    def is_empty(self):
        """ Returns True if the queue is empty"""
        pass

    def first(self):
        """ Returns (but do not remove) the first element in the queue """
        pass

    def enqueue(self, element):
        """ Add "element" to the back of the queue """
        pass

    def dequeue(self):
        """ Remove element from the front of the queue """
        pass
