class _Node:
    """ Node class to create
    individual linked list  nodes """
    def __init__(self, element, next):
        self._element = element
        self._next = next
