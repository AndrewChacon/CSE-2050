import unittest
from Lab2 import Polygon, Triangle, Rectangle


class TestLab2(unittest.TestCase):
    def test_init(self):

        a1 = Polygon(3);
        self.assertEqual(a1.whoamI(),"Triangle")
        self.assertEqual(a1.howmanysides(), 3)
        a2 = Polygon(4);
        self.assertEqual(a2.whoamI(),"Rectangle")
        self.assertEqual(a2.howmanysides(), 4)

    def test_area(self):
        pass #Test the area methods

    def test_perimeter(self):

       pass #Test the perimeter methods


if (__name__ == '__main__'):
    unittest.main()
