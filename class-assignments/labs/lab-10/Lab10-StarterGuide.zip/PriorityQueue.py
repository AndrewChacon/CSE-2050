class Entry:
    def __init__(self, item, priority):
        self.item = item
        self.priority = priority

    def __lt__(self, other):
        return self.priority < other.priority

class Heap:
    def __init__(self):
        self._heap = []

    def insert(self, item, priority):
        pass

    def _upheap(self, i):
        pass

    def _swap(self, c, p):
        self._heap[c], self._heap[p] = self._heap[p], self._heap[c]

    def findmin(self):
        pass

    def removemin(self):
        pass

    def _downheap(self, p_idx):
        pass


    def _has_left_child(self, i):
        return self._left(i) < len(self._heap)

    def _has_right_child(self, i):
        return self._right(i) < len(self._heap)

    def _parent(self, i):
        return (i - 1)//2

    def _left(self, i):
        return 2*i + 1

    def _right(self, i):
        return 2*i + 2

if __name__ == '__main__':

    heap = Heap()
    heap.insert("A", 13)
    heap.insert("B", 2)
    heap.insert("C", 0)
    heap.insert("D", 8)
    heap.insert("E", 1)
    heap.insert("F", 5)
    heap.insert("G", 25)

    print(f"min: {heap.findmin()}")
    heap.removemin()
    heap.removemin()
    for entry in heap._heap:
        print(f"item: {entry.item}", end=" ")
        print(f"priority: {entry.priority}")
