# Your name:
# Your ID:
# Your section (z82L or z81L):

from BST import BSTNode, BinarySearchTree

class AVLNode(BSTNode):
    def __init__(self, data, parent=None):
        #Inheriting required attributes from BSTNode
        super().__init__(data, parent)

        #Additional "height" attribute for AVLTree Implementation
        self.height = 0

class AVLTree(BinarySearchTree):
    def __init__(self):
        super().__init__()

    #overriding _add_child method from BinarySearchTree Class
    def _add_child(self, data, p_node):
        if data == p_node.data:
            return

        if data < p_node.data:
            if p_node.left: #left child exist
                self._add_child(data, p_node.left)

            else:
                p_node.left = AVLNode(data, p_node)
                #after adding node, update the height parameter
                p_node.height = max(self._calc_height(p_node.left), self._calc_height(p_node.right)) + 1
        else:
            if p_node.right:
                self._add_child(data, p_node.right)
            else:
                p_node.right = AVLNode(data, p_node)
                #after adding node, update the height parameter
                p_node.height = max(self._calc_height(p_node.left), self._calc_height(p_node.right)) + 1

        #after insertion, check for balanced tree violations and fix them
        self._fix_violations(p_node)

    #overriding remove_node method from BinarySearchTree Class
    def remove_node(self, data, node):
        if node is None:
            return

        if data < node.data:
            self.remove_node(data, node.left)
        elif data > node.data:
            self.remove_node(data, node.right)
        else:
            if node.left is None and node.right is None:
                #*** if the node is a leaf node ***#
                parent = node.parent

                if parent is not None:
                    if parent.right == node:
                        parent.right = None
                    if parent.left == node:
                        parent.left = None
                else:
                    self.root = None

                del node

                #after deletion, check and fix if the AVL Tree is imbalanced.
                self._fix_violations(parent)

            elif node.left is None and node.right is not None:
                #*** if the node has a right child ***#
                parent = node.parent

                if parent is not None:
                    if parent.right == node:
                        parent.right = node.right
                    if parent.left == node:
                        parent.left = node.right
                else:
                    self.root = node.right

                node.right.parent = parent
                del node

                #after deletion, check and fix if the AVL Tree is imbalanced.
                self._fix_violations(parent)

            elif node.left is not None and node.right is None:
                #*** if the node has a left child ***#
                print(f"Removing node having a left child with data: {node.data}")
                parent = node.parent

                if parent is not None:
                    if parent.right == node:
                        parent.right = node.left
                    if parent.left == node:
                        parent.left = node.left
                else:
                    self.root = node.left

                node.left.parent = parent
                del node

                #after deletion, check and fix if the AVL Tree is imbalanced.
                self._fix_violations(parent)

            else:
                #*** if the node has two children ***#
                predecessor = self.get_predecessor(node.left)
                predecessor.data, node.data = node.data, predecessor.data
                self.remove_node(data, predecessor)

    #Calculate the height of the node.
    def _calc_height(self, node):
        # If the node is None, return -1,
        # otherwise return the default height
        if node is None:
            return -1

        return node.height

    #check if the tree is imbalanced.
    def _fix_violations(self, p_node):
        #Starting from the current node, check all the way up till root node
        # i.e. when the parent node becomes None.
        # 20 points
        pass
        #Check the height of the node first using _calc_height(node) method and
        #then call the helper function _fix_violations_helper(node) to
        #check the balance factor of the node and make necessary rotations.

    def _fix_violations_helper(self, node):
        #first obtain the balance factor using _calc_balance_factor(node) method
        # 20 points
        pass
        #Checking if the tree is LEFT heavy

            #there could be two possibilities - left-right heavy, left-left heavy

            #check left-right heavy situation (See slide 20-22 Week-12-BalancedBST.pdf)
            #check balance factor of left node. If -ve, rotate it to left first


            #If balance factor of left node is +ve, it is left-left heavy situation
            #rotate the node to right


        #Checking if the tree is RIGHT heavy

            #there could be two possibilities - righ-left heavy, right-right heavy

            #check right-left heavy situation (See slide 24-26 Week-12-BalancedBST.pdf)
            #check balance factor of right node. If +ve, rotate it to right first



            #If balance factor of right node is -ve, it is right-right` heavy situation
            #rotate the node to left


    #Calculate and return the balance factor
    def _calc_balance_factor(self, node):
        #10 points
        pass

    def _rotate_left(self, node):
        #Rotate left
        #Look at the hand written notes for explanation
        #25 points
        pass

    def _rotate_right(self, node):
        #Rotate right
        #It works exactly similar to rotate left method except that the
        #left and right attributes will be interchanged.
        #Seek help from the replica example for left rotation.
        #25 points
        pass


if __name__ == '__main__':

    #checking simple tree
    avl = AVLTree()
    avl.insert(5)
    avl.insert(3)
    avl.insert(6)
    avl.insert(1)
    avl.delete(6)
    #After deleting, the tree should balance itself and make 3 as a root node
    assert (avl.root.data == 3)
    print("Test 1 PASSED!")

    #checking nested rotation
    avl = AVLTree()
    avl.insert(32)
    avl.insert(10)
    avl.insert(1)
    assert (avl.root.data == 10)
    print("Test 2 PASSED!")

    avl.insert(55)
    avl.insert(41)
    avl.insert(19)
    avl.insert(16)
    assert (avl.root.data == 32)
    print("Test 3 PASSED!")

    #Checking if the internal rotation worked.
    #This is the case shown on slides 28-37 in Week12-BalancedBST.pdf lecture slides file
    avl.insert(12)
    assert (avl.root.left.right.data == 16)
    print("Test 4 PASSED!")
